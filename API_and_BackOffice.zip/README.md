# Projet_smartCity

## You can find the readme of the Back-Office in the Back-Office folder, and the readme of the API in the API folder.
